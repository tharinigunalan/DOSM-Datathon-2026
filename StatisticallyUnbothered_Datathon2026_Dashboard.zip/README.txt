TourAI: Beyond The Famous
Malaysian Tourism Intelligence Dashboard
DOSM Datathon 2026

============================================================
1. PROJECT OVERVIEW
============================================================

TourAI: Beyond The Famous is an interactive tourism intelligence
dashboard developed for DOSM Datathon 2026.

The dashboard is designed to help users:
- Explore historical tourism performance across Malaysian states.
- Compare state-level tourism performance with the Malaysia average.
- Review AI-based tourism forecasts for 2025 and 2026.
- Identify potential "hidden gem" states with relatively lower tourism
  volume but positive forecast growth.
- Support data-driven tourism planning and sustainable tourism analysis.

The dashboard contains four main pages:
1. Overview
2. State Insights
3. AI Forecast
4. Hidden Gems


============================================================
2. SOFTWARE REQUIREMENTS
============================================================

Recommended software:
- Microsoft Power BI Desktop
- Version: Please enter the Power BI Desktop version used to create
  the submitted .pbix file before final submission.

Operating system:
- Windows 10 or Windows 11 recommended.

Internet connection:
- Recommended for online map/background map services used by Power BI.

Additional plugins/add-ons:
- No additional plugins or add-ons are required for the standard
  dashboard experience.


============================================================
3. FILES IN THE SUBMISSION PACKAGE
============================================================

Recommended package structure:

TeamName_Datathon2026_Dashboard.zip
|
|-- Dashboard.pdf
|-- Dashboard.pbix
|-- Data.csv / Data.xlsx (if applicable)
|-- README.txt

Please keep all supporting data files together with the Power BI file
if the dashboard uses external/local file connections.


============================================================
4. HOW TO OPEN THE DASHBOARD
============================================================

1. Extract the submitted ZIP/RAR file to a local folder.
2. Install Microsoft Power BI Desktop if it is not already installed.
3. Open the file "Dashboard.pbix".
4. Wait for all visuals to finish loading.
5. If prompted to refresh data, allow the refresh only if the
   supporting data files are available in the extracted folder.
6. Use the page navigation buttons on the left side of the dashboard:
   - Overview
   - State Insights
   - AI Forecast
   - Hidden Gems


============================================================
5. DASHBOARD NAVIGATION GUIDE
============================================================

A. OVERVIEW
------------
Purpose:
Provides a high-level view of Malaysia's historical tourism performance.

Main elements:
- Total Tourist Visits
- Average Tourism Growth
- 3-Year Average Tourist Visits
- State Tourism Ranking
- Tourist Visits by State map
- Malaysia Tourism Trend

How to use:
1. Use the Year slicer to adjust the historical period.
2. Use the State slicer to focus on a specific state.
3. Select a bar, map region, or data point to cross-filter other
   visuals where supported.
4. Use this page to understand overall tourism patterns before moving
   into state-level analysis.

Important note:
The historical trend includes the major COVID-19 travel disruption in
2020-2021.


B. STATE INSIGHTS
-----------------
Purpose:
Allows detailed exploration of tourism performance for an individual
state.

Main elements:
- State selector
- Year range selector
- Selected State Tourism Trend
- 3-Year Average
- Selected State vs Malaysia Average comparison
- Difference vs Malaysia (%)
- Comparison Status
- Annual Tourism Growth

How to use:
1. Select a state from the State dropdown.
2. Adjust the Year range if required.
3. Review the state's tourism trend and 3-year average.
4. Compare the selected state against the Malaysia average.
5. Check the Difference vs Malaysia (%) card and Comparison Status.
6. Review annual tourism growth to identify strong growth or decline
   periods.

Interpretation:
- A positive difference means the selected state's value is above the
  Malaysia comparison average.
- A negative difference means it is below the Malaysia comparison
  average.


C. AI FORECAST
--------------
Purpose:
Shows projected tourism performance for 2025 and 2026 and compares
forecast growth across states.

Main elements:
- 2025 Forecast Tourist Visits
- 2026 Forecast Tourist Visits
- 2025 to 2026 Forecast Change
- AI Forecast Classification 2026
- 2025 vs 2026 Tourist Forecast by State
- Forecast Growth by State

How to use:
1. Review the headline forecast cards for Malaysia.
2. Use the state forecast comparison chart to compare 2025 and 2026.
3. Click a state in the chart to highlight related visuals.
4. Review Forecast Growth (%) to identify states with positive,
   stable, or negative projected growth.
5. Use the classification chart to understand the overall forecast
   distribution.

Important:
Forecast figures are model-based estimates derived from historical
patterns and the indicators used in the analytical model. They should
be interpreted as projections rather than guaranteed future outcomes.


D. HIDDEN GEMS
--------------
Purpose:
Highlights states with potential tourism growth opportunities.

Main elements:
- Top Emerging State
- Hidden Gem Count
- Average Hidden Gem Growth (%)
- Hidden Gem Opportunity Matrix
- Hidden Gem Growth Ranking
- AI Opportunity Insight

How to use:
1. Review the Top Emerging State card.
2. Use the Hidden Gem Growth Ranking to compare identified candidates.
3. Use the opportunity matrix to understand each state's position
   based on:
   - 2026 Forecast Tourist Visits
   - Forecast Growth (%)
4. Read the AI Opportunity Insight for a concise interpretation of the
   strongest identified opportunity.

Opportunity Matrix guide:
- Hidden Gems: lower tourism volume + positive growth
- Growth Leaders: higher tourism volume + positive growth
- Development Opportunities: lower tourism volume + negative growth
- Mature / Declining: higher tourism volume + negative growth

The Hidden Gems page is intended as an exploratory decision-support
view and should not be interpreted as an official tourism ranking.


============================================================
6. INTERACTIVE FEATURES
============================================================

The dashboard may include the following Power BI interactions:
- State dropdown slicers
- Year range slicers
- Cross-filtering between charts
- Cross-highlighting
- Interactive map selection
- Page navigation buttons
- Tooltips when hovering over data points

To clear a selection:
- Click the selected item again, or
- Use the eraser/clear-filter icon on the slicer where available.


============================================================
7. DATA AND ANALYTICAL NOTES
============================================================

- Historical tourism patterns are used to provide state-level insights.
- The dashboard contains historical, comparison, forecast, and
  opportunity-analysis views.
- Forecast results for 2025 and 2026 are estimates produced by the
  analytical/modeling workflow used for this project.
- Hidden-gem identification is based on the project's analytical
  criteria, including forecast tourism volume and forecast growth.
- Tourism performance during 2020-2021 was materially affected by
  COVID-19 travel restrictions and should be interpreted carefully
  when comparing long-term trends.
- Values displayed in millions/billions may be rounded for readability,
  so totals may show small differences from underlying raw values.


============================================================
8. LIMITATIONS AND ASSUMPTIONS
============================================================

1. Forecasts are estimates and are dependent on the quality, coverage,
   and historical patterns of the input data.
2. Exceptional events such as pandemics, natural disasters, policy
   changes, economic shocks, or major tourism campaigns may cause
   actual future tourism performance to differ from forecast values.
3. State-level analysis may not capture differences between individual
   attractions or districts within the same state.
4. The "Hidden Gem" classification is an analytical opportunity
   indicator created for this project; it is not an official DOSM,
   MOTAC, or government classification.
5. Historical comparisons that include 2020-2021 should account for
   the exceptional COVID-19 travel disruption.
6. Map visuals may require an active internet connection to display
   background map tiles correctly.
7. Rounded figures are used in several visuals for readability.


============================================================
9. TROUBLESHOOTING
============================================================

If the dashboard does not open:
- Confirm that Microsoft Power BI Desktop is installed.
- Ensure the .pbix file has been fully extracted from the ZIP/RAR file.
- Try opening the .pbix file directly from Power BI Desktop.

If a map does not display:
- Check the internet connection.
- Confirm that map visuals are enabled in Power BI settings if
  required by the local installation.

If a data source error appears:
- Ensure all submitted supporting data files remain in the same
  extracted project folder.
- If the dashboard was submitted with imported data already embedded,
  the judges can continue reviewing the existing visuals without
  refreshing the data.

If visuals appear blank:
- Clear active slicers/filters.
- Return the Year slicer to the full available range.
- Select "All" in the State filter where available.


============================================================
10. JUDGING / REVIEW SUGGESTED FLOW
============================================================

For a quick review of the dashboard:

1. Start at Overview to understand Malaysia's overall tourism pattern.
2. Open State Insights and select a state to review performance against
   the Malaysia average.
3. Open AI Forecast to examine the 2025-2026 projected outlook.
4. Open Hidden Gems to explore potential lower-volume, positive-growth
   tourism opportunities.

This sequence follows the dashboard's intended storytelling flow:
Historical Performance -> State Diagnosis -> Forecast -> Opportunity.


============================================================
11. PROJECT CONTACT
============================================================

Team Name  : ______________________________
University : ______________________________
Contact    : ______________________________
Email      : ______________________________


============================================================
12. VERSION INFORMATION
============================================================

Dashboard Version : Final Submission
README Version    : 1.0
Date              : 22 September 2026

End of README
